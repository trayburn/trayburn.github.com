Imports System.ServiceModel

Module Module1

    Sub Main()
        Using host as New System.ServiceModel.ServiceHost(gettype(ConcreteCalculator))
            host.Open()

            Console.WriteLine("The service is started...")
            Console.ReadLine()
            host.Close()
        End Using
    End Sub

End Module

<ServiceContract()> _
Public Interface ISampleCalculator
    <OperationContract()> _
    Function Add(ByVal x As Integer, ByVal y As Integer) As Integer

    <OperationContract()> _
    Function Substract(ByVal x As Integer, ByVal y As Integer) As Integer

    <OperationContract()> _
    Function Multiply(ByVal x As Integer, ByVal y As Integer) As Integer

    <OperationContract()> _
    Function Divide(ByVal x As Integer, ByVal y As Integer) As Integer
End Interface

Public Class ConcreteCalculator
    Implements ISampleCalculator

    Public Sub New()

    End Sub

    Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer Implements ISampleCalculator.Add
        Return x + y
    End Function

    Public Function Divide(ByVal x As Integer, ByVal y As Integer) As Integer Implements ISampleCalculator.Divide
        Return x / y
    End Function

    Public Function Multiply(ByVal x As Integer, ByVal y As Integer) As Integer Implements ISampleCalculator.Multiply
        Return x * y
    End Function

    Public Function Substract(ByVal x As Integer, ByVal y As Integer) As Integer Implements ISampleCalculator.Substract
        Return x - y
    End Function
End Class