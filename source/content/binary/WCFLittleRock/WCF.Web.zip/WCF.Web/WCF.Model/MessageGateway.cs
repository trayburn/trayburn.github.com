using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace WCF.Model
{
    public class MessageGateway
    {
        public Int64 CreateMessage(string messageText, Guid userId, DateTime createdAt)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MessageDb"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand("EXEC INSERT_MESSAGE @messageText, @userId, @createdAt", conn))
                {
                    comm.Parameters.AddWithValue("@messageText", messageText);
                    comm.Parameters.AddWithValue("@userId", userId);
                    comm.Parameters.AddWithValue("@createdAt", createdAt);
                    object ret = comm.ExecuteScalar();
                    return Convert.ToInt64(ret); 
                }
            }
        }

        public List<Message> GetPublicTimeLine()
        {
            List<Message> outList = new List<Message>();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MessageDb"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand("exec Select_PublicTimeLine", conn))
                {
                	using (SqlDataReader dr = comm.ExecuteReader())
                    {
                        while(dr.Read())
                        {
                            Message msg = new Message();
                            msg.Id = (Int64) dr[0];
                            msg.MessageText = dr[2].ToString();
                            msg.UserId = (Guid) dr[1];
                            msg.CreatedAt = (DateTime) dr[3];

                            outList.Add(msg);
                        }
                    }
                }
            }

            return outList;
        }

        public List<Message> GetUserTimeLine(Guid userId)
        {
            List<Message> outList = new List<Message>();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MessageDb"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand("exec Select_OtherUserTimeLine @userId", conn))
                {
                    comm.Parameters.AddWithValue("@userId", userId);
                    using (SqlDataReader dr = comm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Message msg = new Message();
                            msg.Id = (Int64)dr[0];
                            msg.MessageText = dr[2].ToString();
                            msg.UserId = (Guid)dr[1];
                            msg.CreatedAt = (DateTime)dr[3];

                            outList.Add(msg);
                        }
                    }
                }
            }

            return outList;
        }

        public List<Message> GetUserAndFriendTimeLine(Guid userId)
        {
            List<Message> outList = new List<Message>();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MessageDb"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand("exec Select_UserTimeLine @userId", conn))
                {
                    comm.Parameters.AddWithValue("@userId", userId);
                    using (SqlDataReader dr = comm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Message msg = new Message();
                            msg.Id = (Int64)dr[0];
                            msg.MessageText = dr[2].ToString();
                            msg.UserId = (Guid)dr[1];
                            msg.CreatedAt = (DateTime)dr[3];

                            outList.Add(msg);
                        }
                    }
                }
            }

            return outList;
        }
    }
}
