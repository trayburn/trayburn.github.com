using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Model
{
    public class Message
    {
        private Guid _UserId;
        public Guid UserId
        {
            get { return _UserId; }
            set
            {
                _UserId = value;
            }
        }

        private string _MessageText;
        public string MessageText
        {
            get { return _MessageText; }
            set
            {
                _MessageText = value;
            }
        }

        private DateTime _CreatedAt;
        public DateTime CreatedAt
        {
            get { return _CreatedAt; }
            set
            {
                _CreatedAt = value;
            }
        }

        private Int64 _Id;
        public Int64 Id
        {
            get { return _Id; }
            set
            {
                _Id = value;
            }
        }
    }
}
