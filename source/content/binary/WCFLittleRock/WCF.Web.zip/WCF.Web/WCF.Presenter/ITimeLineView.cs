using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Presenter
{
    public interface ITimeLineView
    {
        List<WCF.Model.Message> Messages { set; }
        TimeLineType TimeLineType { get; }
        Guid UserId { get; }
    }
}
