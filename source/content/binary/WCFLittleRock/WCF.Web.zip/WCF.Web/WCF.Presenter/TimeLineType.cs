using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Presenter
{
    public enum TimeLineType
    {
        Public,
        UserTimeLine,
        OtherUserTimeLine
    }
}
