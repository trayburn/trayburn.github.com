using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Presenter
{
    public interface IPostMessageView
    {
        DateTime CreatedAt { get; }
        string Message { get; }
        Guid UserId { get; }
    }
}
