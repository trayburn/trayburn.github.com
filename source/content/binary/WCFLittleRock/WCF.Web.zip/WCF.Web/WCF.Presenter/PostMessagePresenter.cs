using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Presenter
{
    public class PostMessagePresenter
    {
        IPostMessageView _view;

        public PostMessagePresenter(IPostMessageView view)
        {
            _view = view;
        }

        public void PostMessage()
        {
            Model.MessageGateway gateway = new WCF.Model.MessageGateway();
            gateway.CreateMessage(_view.Message, _view.UserId, _view.CreatedAt);
        }
    }
}
