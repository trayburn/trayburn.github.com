using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.Presenter
{
    public class TimeLinePresenter
    {
        ITimeLineView _view;

        public TimeLinePresenter(ITimeLineView view)
        {
            _view = view;
        }

        public void RetrieveTimeLine()
        {
            Model.MessageGateway gateway = new WCF.Model.MessageGateway();

            switch (_view.TimeLineType)
            {
                case TimeLineType.Public:
                    _view.Messages = gateway.GetPublicTimeLine();
                    break;
                case TimeLineType.UserTimeLine:
                    _view.Messages = gateway.GetUserAndFriendTimeLine(_view.UserId);
                    break;
                case TimeLineType.OtherUserTimeLine:
                    _view.Messages = gateway.GetUserTimeLine(_view.UserId);
                    break;
                default:
                    throw new Exception(String.Format("Unknown Enumeration type: {0}", _view.TimeLineType.ToString()));
            }
        }
    }
}