using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using WCF.Presenter;

public partial class _Default : Page, ITimeLineView, IPostMessageView
{
    private MembershipUser _user;
    private string _specificUser;

    protected void Page_Load(object sender, EventArgs e)
    {
        _user = Membership.GetUser();
        _specificUser = Request.QueryString["user"];

        TimeLinePresenter presenter = new TimeLinePresenter(this);
        presenter.RetrieveTimeLine();
    }

    protected void UpdateButton_Click(object sender, EventArgs e)
    {
        PostMessagePresenter pmPresenter = new PostMessagePresenter(this);
        pmPresenter.PostMessage();

        TimeLinePresenter tlPresenter = new TimeLinePresenter(this);
        tlPresenter.RetrieveTimeLine();

        TextBox msgTB = FindControlRecursive(Page, "MessageTextbox") as TextBox;
        msgTB.Text = string.Empty;
    }

    #region ITimeLineView Members

    public System.Collections.Generic.List<WCF.Model.Message> Messages
    {
        set 
        {
            GridView1.DataSource = value;
            GridView1.DataBind();
        }
    }

    public TimeLineType TimeLineType
    {
        get 
        {
            if (_specificUser != null)
            {
                MembershipUser lUser = Membership.GetUser(_specificUser);
                if (lUser != null)
                    return TimeLineType.OtherUserTimeLine;
            }
            if (_user != null)
                return TimeLineType.UserTimeLine;
            
            return TimeLineType.Public;
        }
    }

    public Guid UserId
    {
        get 
        {
            MembershipUser lUser;

            if (_specificUser != null && 
                (lUser = Membership.GetUser(_specificUser)) != null)
                return (Guid) lUser.ProviderUserKey;

            return (Guid)_user.ProviderUserKey;
        }
    }

    #endregion

    #region IPostMessage Members

    public DateTime CreatedAt
    {
        get { return DateTime.Now; }
    }

    public string Message
    {
        get 
        {

            TextBox msgTB = FindControlRecursive(Page, "MessageTextbox") as TextBox;
            return msgTB.Text; 
        }
    }

    #endregion
    
    private Control FindControlRecursive(Control root, string id)
    {
        if (root.ID == id)
        {
            return root;
        }

        foreach (Control c in root.Controls)
        {
            Control t = FindControlRecursive(c, id);
            if (t != null)
            {
                return t;
            }
        }

        return null;
    } 

}
