using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

namespace ConsoleWCF
{
    class Program
    {
        static void Main(string[] args)
        {
            using(ServiceHost host = new ServiceHost(typeof(ConcreteCalculator)))
            {
                host.Open();

                System.Console.WriteLine("ServiceHost is running...");
                System.Console.ReadLine(); // Blocking Call Here...
            }

        }
    }
}
