using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

namespace ConsoleWCF
{
    public interface ISampleCalculatorCallback
    {
        [OperationContract]
        void Progress(string message);
    }
}
