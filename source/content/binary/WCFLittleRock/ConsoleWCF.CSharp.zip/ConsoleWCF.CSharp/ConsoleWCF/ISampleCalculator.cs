using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

namespace ConsoleWCF
{
    [ServiceContract(Namespace="http://TimRayburn.net/WCF/2007/06")]
    public interface ISampleCalculator
    {
        [OperationContract()]
        int Add(int x, int y);

        [OperationContract()]
        int Multiply(int x, int y);

        [OperationContract()]
        int Subtract(int x, int y);

        [OperationContract()]
        int Division(int x, int y);
    }
}
