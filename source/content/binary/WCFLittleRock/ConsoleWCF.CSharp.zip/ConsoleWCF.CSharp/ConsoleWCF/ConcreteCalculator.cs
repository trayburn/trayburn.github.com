using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Timers;

namespace ConsoleWCF
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant, InstanceContextMode = InstanceContextMode.PerSession)]
    public class ConcreteCalculator : ISampleCalculator
    {
        /// <summary>
        /// Initializes a new instance of the ConcreteCalculator class.
        /// </summary>
        public ConcreteCalculator()
        {
        }

        #region ISampleCalculator Members

        public int Add(int x, int y)
        {
            return x + y;
        }

        public int Multiply(int x, int y)
        {
            return x * y;
        }

        public int Subtract(int x, int y)
        {
            return x - y;
        }

        public int Division(int x, int y)
        {
            return x / y;
        }

        #endregion
    }
}
