using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class LinkDestination
    {
        internal LinkDestination(MapPageLink link, string linkText, LinkType type)
        {
            this._link = link;
            this._text = linkText;
            this._linkType = type;

            int ignore; // Needed for TryParse but not used.
            if (Int32.TryParse(this._text, out ignore))
                this._destinationType = LinkDestinationType.Functoid;
            else
                this._destinationType = LinkDestinationType.Schema;
        }

        private MapPageFunctoid _functoid;
        public MapPageFunctoid Functoid
        {
            get
            {
                if (this.DestinationType == LinkDestinationType.Schema)
                    return null;
                if (_functoid != null)
                    return _functoid;

                foreach(MapPageFunctoid loopFunc in this.Page.Functoids)
                    if (loopFunc.ID == Convert.ToInt32(this.Text))
                    {
                        _functoid = loopFunc;
                        return _functoid;
                    }

                throw new Exception(String.Format("Unable to find functoid with ID of {0}. Map integrity map be compromised.", this.Text));
            }
        }

        private LinkDestinationType _destinationType;
        public LinkDestinationType DestinationType
        {
            get
            {
                return _destinationType;
            }
        }

        private string _text;
        public string Text
        {
            get
            {
                return _text;
            }
        }

        private LinkType _linkType;
        public LinkType LinkType
        {
            get
            {
                return _linkType;
            }
        }

        private MapPageLink _link;
        public MapPageLink Link
        {
            get
            {
                return _link;
            }
        }

        public MapPage Page
        {
            get
            {
                return _link.Page;
            }
        }

        public Map Map
        {
            get
            {
                return _link.Map;
            }
        }
    }
}
