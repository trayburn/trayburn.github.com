using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop
{
    public interface IMapCopView
    {
        string Filename { get; }
        List<MapError> Errors { set; }
        List<IMapRule> Rules { get; set; }
    }
}
