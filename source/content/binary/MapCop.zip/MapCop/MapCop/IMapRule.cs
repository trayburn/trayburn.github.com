using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop
{
    public interface IMapRule
    {
        List<MapError> AnalyzeMap(Map map);
    }
}
