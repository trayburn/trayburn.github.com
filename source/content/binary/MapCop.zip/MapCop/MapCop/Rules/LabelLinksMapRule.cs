using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop.Rules
{
    class LabelLinksMapRule : IMapRule
    {
        #region IMapRule Members

        public List<MapError> AnalyzeMap(Map map)
        {
            List<MapError> errList = new List<MapError>();

            foreach(MapPage loopPage in map.Pages)
            {
                foreach(MapPageLink loopLink in loopPage.Links)
                {
                    if (loopLink.LinkFrom.DestinationType == LinkDestinationType.Functoid &&
                        loopLink.LinkTo.DestinationType == LinkDestinationType.Functoid &&
                        loopLink.Label.Trim().Length.Equals(0))
                    {
                        MapError newError = new MapError();
                        newError.Page = loopPage;
                        newError.Severity = ErrorSeverity.High;
                        newError.Title = "Label all Links between functoids";
                        newError.Description = "All links between functoids should have " + 
                            "their Label property set to ensure readability of functoid " + 
                            "parameter boxes.";

                        errList.Add(newError);
                    }
                }
            }

            return errList;
        }

        #endregion
    }
}
