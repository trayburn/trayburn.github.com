using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class FunctoidParameter
    {
        internal FunctoidParameter(MapPageFunctoid functoid, XmlNode paramNode)
        {
            this._functoid = functoid;
            this._guid = new Guid(paramNode.Attributes["Guid"].Value);
            this._value = paramNode.Attributes["Value"].Value;

            string type = paramNode.Attributes["Type"].Value;
            switch (type)
            {
                case "Link":
                    this._type = ParameterType.Link;
                    break;
                case "Constant":
                    this._type = ParameterType.Constant;
                    break;
                default:
                    throw new Exception(String.Format("Unknown Parameter Type : {0}", type));
            }
        }

        private MapPageFunctoid _functoid;
        public MapPageFunctoid Functoid
        {
            get
            {
                return _functoid;
            }
        }
        public MapPage Page
        {
            get
            {
                return _functoid.Page;
            }
        }
        public Map Map
        {
            get
            {
                return _functoid.Map;
            }
        }

        private ParameterType _type;
        public ParameterType Type
        {
            get
            {
                return _type;
            }
        }

        private Guid _guid;
        public Guid Guid
        {
            get
            {
                return _guid;
            }
        }

        private string _value;
        public string Value
        {
            get
            {
                return _value;
            }
        }

        public MapPageLink Link
        {
            get
            {
                if (this.Type == ParameterType.Constant)
                    return null;

                foreach(MapPageLink loopLink in this.Page.Links)
                {
                    if (loopLink.ID == Convert.ToInt32(this.Value))
                        return loopLink;
                }

                throw new Exception(String.Format("Functoid with ID of {0} not found.  Map integrity may be compromised.", this.Value));
            }
        }
    }
}
