using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public enum LinkType
    {
        LinkFrom,
        LinkTo
    }
}
