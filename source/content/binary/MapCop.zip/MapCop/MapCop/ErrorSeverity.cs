using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop
{
    public enum ErrorSeverity
    {
        /// <summary>
        /// Critical errors affect map stability or performance
        /// or could cause unexpected results.
        /// </summary>
        Critical,
        /// <summary>
        /// High errors include best practices and readability
        /// errors on maps.
        /// </summary>
        High,
        /// <summary>
        /// Medium errors encapsulate those which can sometimes
        /// be acceptable if used sufficiently rarely.
        /// </summary>
        Medium,
        /// <summary>
        /// Low errors encompass those which can be a problem
        /// if used profusely, but used sparingly are acceptable.
        /// </summary>
        Low
    }
}
