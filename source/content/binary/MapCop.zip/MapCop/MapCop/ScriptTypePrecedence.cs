using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class ScriptTypePrecedence
    {
        internal ScriptTypePrecedence(Map map, string scriptType, string enabled)
        {
            this._map = map;

            if (enabled.ToLower() == "yes")
                this._enabled = true;
            else 
                this._enabled = false;

            switch (scriptType)
            {
                case "CSharp":
                    this._scriptType = ScriptType.CSharp;
                    break;
                case "ExternalAssembly":
                    this._scriptType = ScriptType.ExternalAssembly;
                    break;
                case "VbNet":
                    this._scriptType = ScriptType.VbNet;
                    break;
                case "JScript":
                    this._scriptType = ScriptType.JScript;
                    break;
                case "XsltCallTemplate":
                    this._scriptType = ScriptType.XsltCallTemplate;
                    break;
                case "Xslt":
                    this._scriptType = ScriptType.Xslt;
                    break;
                default:
                    throw new Exception(String.Format("Unknown Enumeration Value : {0}", scriptType));
            }
        }

        private bool _enabled;
        public bool Enabled
        {
            get
            {
                return _enabled;
            }
        }

        private ScriptType _scriptType;
        public ScriptType ScriptType
        {
            get
            {
                return _scriptType;
            }
        }

        private Map _map;
        public Map Map
        {
            get
            {
                return _map;
            }
        }
    }
}
