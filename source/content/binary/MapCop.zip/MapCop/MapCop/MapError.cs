using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop
{
    public class MapError
    {
        public MapError()
        {
        }

        private MapPage _page;
        public MapPage Page
        {
            get
            {
                return _page;
            }
            set
            {
                _page = value;
            }
        }

        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        private string _description;
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        private ErrorSeverity _severity;
        public ErrorSeverity Severity
        {
            get
            {
                return _severity;
            }
            set
            {
                _severity = value;
            }
        }
    }
}
