using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class MapPageLink
    {
        internal MapPageLink(MapPage page, XmlNode linkNode)
        {
            this._page = page;
            this._id = Convert.ToInt32(linkNode.Attributes["LinkID"].Value);
            this._label = linkNode.Attributes["Label"].Value;
            this._linkFrom = new LinkDestination(this,linkNode.Attributes["LinkFrom"].Value, LinkType.LinkFrom);
            this._linkTo = new LinkDestination(this, linkNode.Attributes["LinkTo"].Value, LinkType.LinkTo);
        }

        private MapPage _page;
        public MapPage Page
        {
            get
            {
                return _page;
            }
        }
        public Map Map
        {
            get
            {
                return _page.Map;
            }
        }
        private int _id;
        public int ID
        {
            get
            {
                return _id;
            }
        }
        private string _label;
        public string Label
        {
            get
            {
                return _label;
            }
        }

        private LinkDestination _linkFrom;
        public LinkDestination LinkFrom
        {
            get
            {
                return _linkFrom;
            }
        }

        private LinkDestination _linkTo;
        public LinkDestination LinkTo
        {
            get
            {
                return _linkTo;
            }
        }
    }
}
