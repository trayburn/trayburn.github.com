using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public enum ScriptType
    {
        CSharp,
        ExternalAssembly,
        VbNet,
        JScript,
        XsltCallTemplate,
        Xslt
    }
}
