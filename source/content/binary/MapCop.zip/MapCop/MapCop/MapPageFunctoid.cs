using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class MapPageFunctoid
    {
        private string paramXpath = "child::Input-Parameters/Parameter";

        internal MapPageFunctoid(MapPage page, XmlNode functoidNode)
        {
            this._page = page;
            this._id = Convert.ToInt32(functoidNode.Attributes["FunctoidID"].Value);
            this._xCell = Convert.ToInt32(functoidNode.Attributes["X-Cell"].Value);
            this._yCell = Convert.ToInt32(functoidNode.Attributes["Y-Cell"].Value);
            this._functoidId = Convert.ToInt32(functoidNode.Attributes["Functoid-FID"].Value);
            this._name = functoidNode.Attributes["Functoid-Name"].Value;
            this._label = functoidNode.Attributes["Label"].Value;

            if (functoidNode.Attributes["Functoid-CLSID"] != null)
                this._clsId = new Guid(functoidNode.Attributes["Functoid-CLSID"].Value);
            else
                this._clsId = null;

            XmlNodeList paramList = functoidNode.SelectNodes(paramXpath);
            foreach(XmlNode loopParam in paramList)
                this._parameters.Add(new FunctoidParameter(this,loopParam));
        }

        private List<FunctoidParameter> _parameters = new List<FunctoidParameter>();
        public List<FunctoidParameter> Parameters
        {
            get
            {
                return _parameters;
            }
        }

        private MapPage _page;
        public MapPage Page
        {
            get
            {
                return _page;
            }
        }
        public Map Map
        {
            get
            {
                return _page.Map;
            }
        }
        private int _id;
        public int ID
        {
            get
            {
                return _id;
            }
        }
        private int _xCell;
        public int XCell
        {
            get
            {
                return _xCell;
            }
        }

        private int _yCell;
        public int YCell
        {
            get
            {
                return _yCell;
            }
        }

        private Guid? _clsId;
        public Guid? ClsId
        {
            get
            {
                return _clsId;
            }
        }

        private int _functoidId;
        public int FunctoidId
        {
            get
            {
                return _functoidId;
            }
        }

        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
        }

        private string _label;
        public string Label
        {
            get
            {
                return _label;
            }
        }
    }
}
