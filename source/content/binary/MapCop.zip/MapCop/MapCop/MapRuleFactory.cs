using System;
using System.Collections.Generic;
using System.Text;
using MapCop.Rules;

namespace MapCop
{
    public sealed class MapRuleFactory
    {
        public static List<IMapRule> GetAllRules()
        {
            List<IMapRule> allRules = new List<IMapRule>();
            allRules.Add(new Rules.LabelLinksMapRule());
            return allRules;
        }
    }
}
