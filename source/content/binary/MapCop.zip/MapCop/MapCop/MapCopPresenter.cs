using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop
{
    public class MapCopPresenter
    {
        private readonly IMapCopView view;

        /// <summary>
        /// Initializes a new instance of the MapCopPresenter class.
        /// </summary>
        /// <param name="view"></param>
        public MapCopPresenter(IMapCopView view)
        {
            this.view = view;
            this.view.Rules = MapRuleFactory.GetAllRules();
        }

        public void AnalyzeMap()
        {
            List<MapError> lErrors = new List<MapError>();
            Map lMap = new Map(view.Filename);
            
            foreach(IMapRule loopRule in view.Rules)
                lErrors.AddRange(loopRule.AnalyzeMap(lMap));

            view.Errors = lErrors;
        }
    }
}
