using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MapCop
{
    public class MapPage
    {
        private string linkXpath = "child::Links/Link";
        private string functoidXpath = "child::Functoids/Functoid";

        internal MapPage(Map map, XmlNode pageNode)
        {
            this._map = map;
            this._name = pageNode.Attributes["Name"].Value;

            XmlNodeList linkList = pageNode.SelectNodes(linkXpath);
            foreach(XmlNode loopLink in linkList)
                this.Links.Add(new MapPageLink(this,loopLink));

            XmlNodeList funcList = pageNode.SelectNodes(functoidXpath);
            foreach(XmlNode loopFunc in funcList)
                this.Functoids.Add(new MapPageFunctoid(this,loopFunc));
        }

        private Map _map;
        public Map Map
        {
            get
            {
                return _map;
            }
        }

        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
        }

        private List<MapPageLink> _links = new List<MapPageLink>();
        public List<MapPageLink> Links
        {
            get
            {
                return _links;
            }
        }

        private List<MapPageFunctoid> _functoids = new List<MapPageFunctoid>();
        public List<MapPageFunctoid> Functoids
        {
            get
            {
                return _functoids;
            }
        }
    }
}
