using System;
using System.Collections.Generic;
using System.Text;
using MapCop;

namespace MapCop_Console
{
    class MapCopConsole : IMapCopView
    {
        static void Main(string[] args)
        {
            // Display the banner
            Console.WriteLine("MapCop-Console version 0.1");
            Console.WriteLine("Copyright 2006 Tim Rayburn, All Rights Reserved");
            Console.WriteLine();

            // Check for the proper number of arguments.
            if (args.GetUpperBound(0) != 1)
            {
                Console.WriteLine("Only one parameter is accepted for MapCop-Console.");
                return;
            }

            // Check for help switch
            string inputArg = args[0];
            if (inputArg.ToLower().Trim() == "/?" || 
                inputArg.ToLower().Trim() == "/help")
            {
                Console.WriteLine("MapCop-Console [MapFilename]");
                Console.WriteLine();
                Console.WriteLine("\t[MapFilename] is the path to a BizTalk Map (.BTM) to be analyzed.");
            }

            MapCopConsole conView = new MapCopConsole();
            MapCopPresenter presenter = new MapCopPresenter(conView);
            conView._filename = inputArg;
            presenter.AnalyzeMap();

            Console.WriteLine("{0} Errors Detected", conView._errors.Count);
            Console.WriteLine();

            foreach (MapError loopError in conView._errors)
            {
                Console.WriteLine(loopError.Title);
                Console.WriteLine("Severity : {0}", loopError.Severity.ToString());
                Console.WriteLine("Page : {0}", loopError.Page.Name);
                Console.WriteLine("Description : {0}", loopError.Description);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine();
            }

        }

        #region IMapCopView Members

        private string _filename;
        public string Filename
        {
            get { return _filename; }
        }

        private List<MapError> _errors;
        public List<MapError> Errors
        {
            set { _errors = value; }
        }

        private List<IMapRule> _rules;
        public List<IMapRule> Rules
        {
            get
            {
                return _rules;
            }
            set
            {
                _rules = value;
            }
        }

        #endregion
    }
}
