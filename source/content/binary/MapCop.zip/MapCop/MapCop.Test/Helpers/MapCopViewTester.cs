using System;
using System.Collections.Generic;
using System.Text;

namespace MapCop.Test.Helpers
{
    class MapCopViewTester :  MapCop.IMapCopView
    {
        #region IMapCopView Members

        private string _filename;
        public string Filename
        {
            get { return _filename; }
            set
            {
            	_filename = value;
            }
        }

        private List<MapError> _errs;
        public List<MapError> Errors
        {
            get
            {
                return _errs;
            }
            set { _errs = value; }
        }

        private List<IMapRule> _rules;
        public List<IMapRule> Rules
        {
            get
            {
                return _rules;
            }
            set
            {
                _rules = value;
            }
        }

        #endregion
    }
}
