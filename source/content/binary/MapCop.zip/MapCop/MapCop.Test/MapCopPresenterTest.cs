using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using MapCop.Test.Helpers;

namespace MapCop.Test
{
    [TestFixture]
    public class MapCopPresenterTest : IDisposable
    {
        private Helpers.MapCopViewTester testView;
        private MapCop.MapCopPresenter presenter;
        TestFile simpleMap;
        string mapFilename = "MapCopPresenterTestTestMap.btm";

        public MapCopPresenterTest()
        {
            simpleMap = new TestFile(mapFilename, 
                "MapCop.Test.TestData.SimpleMap.btm");
        }


        [SetUp]
        public void Setup()
        {
            testView = new Helpers.MapCopViewTester();
            presenter = new MapCopPresenter(testView);
        }

        [TearDown]
        public void TearDown()
        {
            testView = null;
            presenter = null;
        }

        [Test]
        public void AnalyzeMap()
        {
            testView.Filename = mapFilename;
            presenter.AnalyzeMap();
        }

        [Test]
        public void ErrorsReturned()
        {
            testView.Filename = mapFilename;
            presenter.AnalyzeMap();
            List<MapError> errList = testView.Errors;

            Console.WriteLine("{0} Errors Detected", errList.Count);
            Console.WriteLine();

            foreach (MapError loopError in errList)
            {
                Console.WriteLine(loopError.Title);
                Console.WriteLine("Severity : {0}", loopError.Severity.ToString());
                Console.WriteLine("Page : {0}", loopError.Page.Name);
                Console.WriteLine("Description : {0}", loopError.Description);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine();
            }

            Assert.IsNotNull(testView.Rules, "Rules List Not Null");
            Assert.Greater(testView.Rules.Count,0, "Proper Rules Count");
            Assert.IsNotNull(errList, "Error List Not Null");
            Assert.Greater(errList.Count,0, "Proper Error Count");
        }
 
        #region IDisposable Members

        public void Dispose()
        {
            simpleMap.Dispose();
        }

        #endregion
    }
}
