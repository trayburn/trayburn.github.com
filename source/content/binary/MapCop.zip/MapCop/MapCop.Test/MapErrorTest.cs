using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using MapCop.Test.Helpers;

namespace MapCop.Test
{
    [TestFixture]
    public class MapErrorTest : IDisposable
    {
        TestFile simpleMap;
        string mapFilename = "MapErrorTestMap.btm";

        public MapErrorTest()
        {
            simpleMap = new TestFile(mapFilename, 
                "MapCop.Test.TestData.SimpleMap.btm");
        }

        [Test]
        public void Construct()
        {
            MapError err = new MapError();
            Assert.IsNotNull(err);
        }

        [Test]
        public void Properties()
        {
            Map testMap = new Map(mapFilename);
            string testString = "123456";
            MapError err = new MapError();
            err.Title = testString;
            err.Description = testString;
            err.Page = testMap.Pages[0];
            err.Severity = ErrorSeverity.High;

            Assert.AreEqual(testString,err.Description);
            Assert.AreEqual(testString,err.Title);
            Assert.AreEqual(testMap.Pages[0],err.Page);
            Assert.AreEqual(ErrorSeverity.High, err.Severity);
        }

        #region IDisposable Members

        public void Dispose()
        {
            simpleMap.Dispose();
        }

        #endregion
    }
}
