﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;

namespace IntroToCSharp3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * About Tim Rayburn & Sogeti
             * 
             * Tim -
             * Microsoft MVP for BizTalk Server
             * Principal Consultant with Sogeti
             * Been professionally developing since 1995
             * Been developing since 1979
             * 
             * Sogeti -
             * IT Services company
             * Division of CapGemini
             * 16,000+ employees world wide
             * 2,000+ employees in the United States
             * Offering services in:
             *  Business Analysis, Project Management
             *  Development, Architecture
             *  Business Intelligence
             * Globally Managed Microsoft Gold Partner
             */
            Console.WriteLine("--------- BEGIN ---------");


            /*
             * x Automatic Properties
             * X Object Initializers
             * X Collection Initializers
             * X Implicitly Typed Variables
             * X Anonymous Types
             * X Lambda Expressions
             * X LINQ
             * X Extension Methods
             * Partial Methods
             */

            // Object Initializers
            Person me = new Person()
            {
                FirstName = "Tim",
                LastName = "Rayburn"
            };
            Console.WriteLine(me.FirstName);

            // Array Initializers -- 2005 Feature
            string[] myArray = new string[] { "T", "I", "M" };

            // Collection Initializers
            string lastName = "Rayburn";
            List<Person> family = new List<Person>()
            {
            	new Person() { FirstName = "Tim", LastName =lastName},
                new Person() { FirstName = "Ray", LastName = lastName},
                new Person() { FirstName = "Mark", LastName = lastName}
            };

            // Implicitly Typed Variables
            var xx = new List<Person>()
            {
            	new Person() { FirstName = "Tim", LastName =lastName},
                new Person() { FirstName = "Ray", LastName = lastName},
                new Person() { FirstName = "Mark", LastName = lastName}
            };
            Console.WriteLine(xx.GetType().Name);

            Console.WriteLine("--------- Anonymous Types ---------");
            // Anonymous Types
            var myX = new
            {
                FirstName = "Tim",
                KoodosRating = 5,
                LastName = "Putz"
            };

            Console.WriteLine(myX.KoodosRating);
            Console.WriteLine(myX.GetType().Name);

            Console.WriteLine("--------- LINQ ---------");
            var myQuery = from loopVar in Directory.GetFiles(@"C:\")
                          where CoinFlip()
                          select new
                          {
                              Extension = Path.GetExtension(loopVar),
                              FileName = Path.GetFileName(loopVar)
                          };

            var myList = myQuery.ToList(); // This executes the query.

            foreach (var loopVar in myList)
            {
                Console.WriteLine(loopVar.FileName);
            }

            Console.WriteLine("==================================");

            foreach (var loopVar in myList)
            {
                Console.WriteLine(loopVar.FileName);
            }
            
            Console.WriteLine("--------- Lambda Expression ---------");

            int myStupidVariable = 21567;
            Console.WriteLine(family.Average(i => 
            {
                return myStupidVariable + i.FirstName.Length + i.LastName.Length;
            }));


            Console.WriteLine("--------- Extension Methods ---------");
            Console.WriteLine(me.FullName());

            DataSet ds = null;
            int age = 5;

            Console.WriteLine(ds.ToStringNullSafe());
            Console.WriteLine(age.ToStringNullSafe());

            Console.WriteLine("--------- END ---------");
            Console.ReadLine();
        }

        private static Random rnd = new Random();
        private static bool CoinFlip()
        {
            return rnd.Next() > (int.MaxValue / 2);
        }
    }

    public static class MyExtensions
    {
        public static string FullName(this IPerson obj)
        {
            return obj.FirstName + " " + obj.LastName ;
        }

        public static string ToStringNullSafe(this Object obj)
        {
            if (obj == null) return string.Empty;
            else return obj.ToString();
        }
    }

    public interface IPerson
    {
        string FirstName { get; set; }
        string MiddleName { get; set; }
        string LastName { get; set; }
    }
    public partial class Person : IPerson
    {
        partial void OnFirstNameChange(string oldValue, string newValue);

        private string _firstName;
        public string FirstName
        { 
            get
            {
                return _firstName;
            }
            set
            {
                if (_firstName != value)
                    OnFirstNameChange(_firstName, value);
                _firstName = value;
            }
        }
        public string MiddleName { get; set; }
        public string LastName { get; set; }

    }

    public partial class Person
    {
        partial void OnFirstNameChange(string oldValue, string newValue)
        {
            if (oldValue.Length > newValue.Length)
            {
                int i = 5;
                i++;
            }
        }
    }
}
