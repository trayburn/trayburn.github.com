﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace IntroToCSharp3
{
    class Program
    {
        /*
         * Tim Rayburn - BizTalk Server MVP
         * Principal Consultant, Sogeti (http://us.sogeti.com)
         * 10+ years working in Development
         * 7+ years working with BizTalk Server
         * 
         * Sogeti USA
         * Global IT Services Company
         * 100+ Dallas Consultants
         * 2,000 U.S. Consultants
         * 16,000 Global Consultants
         * Project Management, IBM/Java Practice, Microsoft Practice
         * Microsoft Gold Partner
         */
        static void Main(string[] args)
        {
            // Object Initializers
            Person p = new Person()
            {
                FirstName = "Tim",
                LastName = "Rayburn"
            };

            // Array Initializers (VS2005)
            string[] myArray = new string[] { "A", "B", "D" };

            // Collection Initializers
            List<string> myList = new List<string>() { "A", "B", "D" };
            List<Person> myFamily = new List<Person>()
            {
                new Person() { FirstName = "Tim", LastName="Rayburn"},
                new Person() { FirstName = "Chris", LastName="Rayburn"},
                new Person() { FirstName = "Mark", LastName="Rayburn"},
                new Person() { FirstName = "James", LastName="Rayburn"}
            };

            // Implicitly Typed Variables
            var thisIsCool = new Person()
            {
                FirstName = "Tim",
                LastName = "Rayburn"
            };

            // Anonymous Types
            var myAnon = new
            {
                FirstName = "Tim",
                LastName = "Rayburn",
                MunchkinValue = 5
            };

            // LINQ
            var fileList = Directory.GetFiles(@"c:\");

            var myQuery = from i in fileList
                          where CoinFlip()
                          select i;

            var myOtherList = myQuery.ToList();
            var myOtherOtherList = myQuery.ToList();

            foreach (var loopVar in myOtherList)
            {
                Console.WriteLine(loopVar);
            }
            Console.WriteLine("------------------------------------");
            foreach (var loopVar in myOtherOtherList)
            {
                Console.WriteLine(loopVar);
            }
            Console.WriteLine("------------------------------------");
            Console.WriteLine("------------------------------------");

            // Extension Methods (!!)
            IPerson intPerson = thisIsCool as IPerson;
            Console.WriteLine(intPerson.FullName());
            object o = null;
            Console.WriteLine("#" + o.ToStringNullSafe() + "#");

            Console.WriteLine("------------------------------------");
            Console.WriteLine("------------------------------------");
           
            // Lambda Expressions
            Console.WriteLine(myOtherList.Average(GetMyExpression())); 
            Console.ReadLine();

            
        }
        private static Func<string,int> GetMyExpression()
        {
            return j => { return j.Length; };
        }
        private static Random rnd = new Random(DateTime.Now.Second);
        private static bool CoinFlip()
        {
            int val = rnd.Next(int.MaxValue);
            if (val > (int.MaxValue / 2)) return true;
            else return false;
        }
    }
    static class MyExtensions
    {
        public static string ToStringNullSafe(this object obj)
        {
            if (obj == null) return string.Empty;
            else return obj.ToString();
        }
        public static string FullName(this IPerson obj)
        {
            return obj.FirstName + " " + obj.LastName;
        }
    }
    public interface IPerson
    {
        string FirstName { get; set; }
        string MiddleName { get; set; }
        string LastName { get; set; }
    }
    partial class Person
    {
        partial void OnFirstNameChange(string oldValue, string newValue)
        {
            // Insert checking on NewValue vs OldValue....
            string lString = oldValue + newValue;
        }
    }
    partial class Person : IPerson
    {
        // Partial Methods
        partial void OnFirstNameChange(string oldValue, string newValue);

        // Automatic Properties
        private string _FirstName;
        public string FirstName
        {
            get
            {
                return _FirstName;
            }

            set
            {
                OnFirstNameChange(_FirstName, value);
                _FirstName = value;
            }
        }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int MunchkinValue { get; set; }
    }
}
