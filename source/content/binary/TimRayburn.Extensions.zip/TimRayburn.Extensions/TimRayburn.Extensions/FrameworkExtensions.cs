﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace TimRayburn.Extensions
{
    public static class FrameworkExtensions
    {
        public static string ToStringNullSafe(this object inStr)
        {
            if (inStr == null) return string.Empty;
            else
            {
                string lStr = inStr.ToString();
                if (lStr == null) return string.Empty;
                else return lStr;
            }
        }

        public static Int32 ToInt32(this string inStr)
        {
            inStr.EnsureToInt32("inStr");

            return Int32.Parse(inStr);
        }

        public static Double ToDouble(this string inStr)
        {
            inStr.EnsureToDouble("inStr");

            return Double.Parse(inStr);
        }
    }
}
