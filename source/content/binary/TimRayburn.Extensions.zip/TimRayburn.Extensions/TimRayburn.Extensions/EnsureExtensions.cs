﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace TimRayburn.Extensions
{
    public static class EnsureExtensions
    {
        static EnsureExtensions() { }

        private static void Ensure(bool condition, string message, string argumentName)
        {
            if (condition)
                throw new ArgumentException(message, argumentName);
        }

        #region System.Object

        public static object EnsureNotNull(this object obj)
        {
            return obj.EnsureNotNull("Argument");
        }

        public static object EnsureNotNull(this object obj, string argumentName)
        {
            argumentName.EnsureNotNull();

            Ensure(obj == null, String.Format("{0} cannot be null.", argumentName), argumentName);
            return obj;
        }


        #endregion

        #region System.String

        public static string EnsureStartsWith(this string inStr, string startsWith)
        {
            return inStr.EnsureStartsWith(startsWith, "Argument");
        }

        public static string EnsureStartsWith(this string inStr, string startsWith, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            startsWith.EnsureNotNull("startsWith");

            Ensure(!inStr.StartsWith(startsWith), String.Format("{0} must start with '{1}'.", argumentName, startsWith), argumentName);
            return inStr;
        }

        public static string EnsureEndsWith(this string inStr, string endsWith)
        {
            return inStr.EnsureEndsWith(endsWith, "Argument");
        }

        public static string EnsureEndsWith(this string inStr, string endsWith, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            endsWith.EnsureNotNull("endsWith");
            argumentName.EnsureNotNull("argumentName");

            Ensure(!inStr.StartsWith(endsWith), String.Format("{0} must end with '{1}'.", argumentName, endsWith), argumentName);
            return inStr;
        }

        public static string EnsurePathExists(this string inStr, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            argumentName.EnsureNotNull("argumentName");

            Ensure(!(System.IO.Directory.Exists(inStr) || System.IO.File.Exists(inStr)), String.Format("{0} must refer to a file or directory that exists and '{1}' cannot be found.", argumentName, inStr), argumentName);
            return inStr;
        }

        public static string EnsurePathExists(this string inStr)
        {
            return inStr.EnsurePathExists("Argument");
        }

        public static string EnsureFileExists(this string inStr, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            argumentName.EnsureNotNull("argumentName");

            Ensure(!System.IO.File.Exists(inStr), String.Format("{0} must refer to a file that exists and '{1}' cannot be found.", argumentName, inStr), argumentName);
            return inStr;
        }

        public static string EnsureFileExists(this string inStr)
        {
            return inStr.EnsureFileExists("Argument");
        }

        public static string EnsureDirectoryExists(this string inStr, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            argumentName.EnsureNotNull("argumentName");

            Ensure(!System.IO.Directory.Exists(inStr), String.Format("{0} must refer to a directory that exists and '{1}' cannot be found.", argumentName, inStr), argumentName);
            return inStr;
        }

        public static string EnsureDirectoryExists(this string inStr)
        {
            return inStr.EnsureDirectoryExists("Argument");
        }

        public static string EnsureToInt32(this string inStr, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            argumentName.EnsureNotNull("argumentName");

            Int32 lResult;
            Ensure(!Int32.TryParse(inStr, out lResult), String.Format("{0} has a value of '{1}' which cannot be parsed into an Int32.", argumentName, inStr), argumentName);
            return inStr;
        }

        public static string EnsureToDouble(this string inStr, string argumentName)
        {
            inStr.EnsureNotNull("inStr");
            argumentName.EnsureNotNull("argumentName");

            Double lResult;
            Ensure(!Double.TryParse(inStr, out lResult), String.Format("{0} has a value of '{1}' which cannot be parsed into an Double.", argumentName, inStr), argumentName);
            return inStr;
        }

        #endregion

        #region System.IComparable

        public static T EnsureLessThanOrEqualTo<T>(this T inObj, T inValue, string argumentName) where T : IComparable<T>
        {
            argumentName.EnsureNotNull();

            Ensure(!(inObj.CompareTo(inValue) <= 0), String.Format("{0} must be less than or equal to {1}.", argumentName, inValue), argumentName);
            return inObj;
        }

        public static T EnsureLessThanOrEqualTo<T>(this T inObj, T inValue) where T : IComparable<T>
        {
            return inObj.EnsureLessThanOrEqualTo<T>(inValue, "Argument");
        }

        public static T EnsureLessThan<T>(this T inObj, T inValue, string argumentName) where T : IComparable<T>
        {
            argumentName.EnsureNotNull();

            Ensure(!(inObj.CompareTo(inValue) < 0), String.Format("{0} must be less than {1}.", argumentName, inValue), argumentName);
            return inObj;
        }

        public static T EnsureLessThan<T>(this T inObj, T inValue) where T : IComparable<T>
        {
            return inObj.EnsureLessThan<T>(inValue, "Argument");
        }

        public static T EnsureGreaterThan<T>(this T inObj, T inValue, string argumentName) where T : IComparable<T>
        {
            argumentName.EnsureNotNull();

            Ensure(!(inObj.CompareTo(inValue) > 0), String.Format("{0} must be greater than {1}.", argumentName, inValue), argumentName);
            return inObj;
        }

        public static T EnsureGreaterThan<T>(this T inObj, T inValue) where T : IComparable<T>
        {
            return inObj.EnsureGreaterThan<T>(inValue, "Argument");
        }

        public static T EnsureGreaterThanOrEqualTo<T>(this T inObj, T inValue, string argumentName) where T : IComparable<T>
        {
            argumentName.EnsureNotNull();

            Ensure(!(inObj.CompareTo(inValue) >= 0), String.Format("{0} must be greater than or equal to {1}.", argumentName, inValue), argumentName);
            return inObj;
        }

        public static T EnsureGreaterThanOrEqualTo<T>(this T inObj, T inValue) where T : IComparable<T>
        {
            return inObj.EnsureGreaterThanOrEqualTo<T>(inValue, "Argument");
        }

        public static T EnsureEqualTo<T>(this T inObj, T inValue, string argumentName) where T : IComparable<T>
        {
            argumentName.EnsureNotNull();

            Ensure(!(inObj.CompareTo(inValue) == 0), String.Format("{0} must be equal to {1}.", argumentName, inValue), argumentName);
            return inObj;
        }

        public static T EnsureEqualTo<T>(this T inObj, T inValue) where T : IComparable<T>
        {
            return inObj.EnsureEqualTo<T>(inValue, "Argument");
        }

        #endregion


    }
}
