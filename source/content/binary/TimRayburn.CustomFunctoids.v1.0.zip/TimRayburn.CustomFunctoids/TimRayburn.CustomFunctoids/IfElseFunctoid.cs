using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;

namespace TimRayburn.CustomFunctoids
{
    class IfElseFunctoid : BaseFunctoid
    {
        public IfElseFunctoid()
        {
            // Assign a "unique" id to this functiod
            this.ID = 24602;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_IFELSEFUNCTOID_NAME");
            SetTooltip("IDS_IFELSEFUNCTOID_TOOLTIP");
            SetDescription("IDS_IFELSEFUNCTOID_DESCRIPTION");
            SetBitmap("IDB_IFELSEFUNCTOID_BITMAP");

            this.SetMinParams(3);
            this.SetMaxParams(3);

            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.IfElseFunctoid",
                "IfElse");

            this.Category = FunctoidCategory.ValueMapping;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
            AddInputConnectionType(ConnectionType.AllExceptRecord);
            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }

        public string IfElse(string booleanValue, string trueValue, string falseValue)
        {
            bool bVal = System.Convert.ToBoolean(booleanValue);
            if (bVal)
                return trueValue;
            else
                return falseValue;
        }
    }
}
