using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;


namespace TimRayburn.CustomFunctoids
{
    class LogicalContainsFunctoid : BaseFunctoid
    {
        public LogicalContainsFunctoid()
            : base()
        {
            // Assign a "unique" id to this functiod.
            this.ID = 24606;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_LOGICALCONTAINSFUNCTOID_NAME");
            SetTooltip("IDS_LOGICALCONTAINSFUNCTOID_TOOLTIP");
            SetDescription("IDS_LOGICALCONTAINSFUNCTOID_DESCRIPTION");
            SetBitmap("IDS_LOGICALCONTAINSFUNCTOID_BITMAP");

            this.SetMinParams(2);
            this.SetMaxParams(2);

            //set the function name that needs to be 
            //called when this Functoid is invoked. This means that
            //this Functoid assembly need to be present in GAC 
            //for its availability during Test..Map and Runtime.
            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.LogicalContainsFunctoid",
                "LogicalContains");

            this.Category = FunctoidCategory.Logical;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }

        public string LogicalContains(string fullString, string subString)
        {
            // I realize this could be fullString.Contains(subString)
            // but doing that means this could not be compiled
            // under .NET 1.1 for BizTalk 2004
            if (fullString.IndexOf(subString) > 0)
                return "true";
            else
                return "false";
        }
    }
}
