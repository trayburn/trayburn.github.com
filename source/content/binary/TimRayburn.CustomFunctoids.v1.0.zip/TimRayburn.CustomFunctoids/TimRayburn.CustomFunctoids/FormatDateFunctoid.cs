using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;

namespace TimRayburn.CustomFunctoids
{
    class FormatDateFunctoid : BaseFunctoid
    {
        public FormatDateFunctoid()
        {
            // Assign a "unique" id to this functiod
            this.ID = 24604;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_FORMATDATEFUNCTOID_NAME");
            SetTooltip("IDS_FORMATDATEFUNCTOID_TOOLTIP");
            SetDescription("IDS_FORMATDATEFUNCTOID_DESCRIPTION");
            SetBitmap("IDB_FORMATDATEFUNCTOID_BITMAP");

            this.SetMinParams(3);
            this.SetMaxParams(3);

            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.FormatDateFunctoid",
                "FormatDate");

            this.Category = FunctoidCategory.Conversion;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
            AddInputConnectionType(ConnectionType.AllExceptRecord);
            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }
        public string FormatDate(string inDate, string inFormat, string outFormat)
        {
            System.Globalization.CultureInfo ci = 
                System.Threading.Thread.CurrentThread.CurrentCulture;
            DateTime lDate = System.DateTime.ParseExact(inDate, inFormat, ci);
            return lDate.ToString(outFormat,ci);
        }
    }
}
