using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;


namespace TimRayburn.CustomFunctoids
{
    class LogicalStartsWithFunctoid : BaseFunctoid
    {
        public LogicalStartsWithFunctoid()
            : base()
        {
            // Assign a "unique" id to this functiod.
            this.ID = 24607;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_LOGICALSTARTSWITHFUNCTOID_NAME");
            SetTooltip("IDS_LOGICALSTARTSWITHFUNCTOID_TOOLTIP");
            SetDescription("IDS_LOGICALSTARTSWITHFUNCTOID_DESCRIPTION");
            SetBitmap("IDS_LOGICALSTARTSWITHFUNCTOID_BITMAP");

            this.SetMinParams(2);
            this.SetMaxParams(2);

            //set the function name that needs to be 
            //called when this Functoid is invoked. This means that
            //this Functoid assembly need to be present in GAC 
            //for its availability during Test..Map and Runtime.
            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.LogicalStartsWithFunctoid",
                "LogicalStartsWith");

            this.Category = FunctoidCategory.Logical;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }

        public string LogicalStartsWith(string fullString, string subString)
        {
            if (fullString.StartsWith(subString))
                return "true";
            else
                return "false";
        }
    }
}
