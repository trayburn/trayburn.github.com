using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;

namespace TimRayburn.CustomFunctoids
{
    class TrimmedValueExistsFunctoid : BaseFunctoid
    {
        public TrimmedValueExistsFunctoid(): base()
        {
            // Assign a "unique" id to this functiod
            this.ID = 24603;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_TRIMMEDVALUEEXISTSFUNCTOID_NAME");
            SetTooltip("IDS_TRIMMEDVALUEEXISTSFUNCTOID_TOOLTIP");
            SetDescription("IDS_TRIMMEDVALUEEXISTSFUNCTOID_DESCRIPTION");
            SetBitmap("IDB_TRIMMEDVALUEEXISTSFUNCTOID_BITMAP");

            this.SetMinParams(1);
            this.SetMaxParams(1);

            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.TrimmedValueExistsFunctoid",
                "TrimmedValueExists");

            this.Category = FunctoidCategory.Logical;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }
        public string TrimmedValueExists(string inputVal)
        {
            if (inputVal.Length.Equals(0))
                return "true";
            else
            {
                string trimmedVal = inputVal.Trim();
                if (trimmedVal.Length.Equals(0))
                    return "true";
                else
                    return "false";
            }
        }
    }
}
