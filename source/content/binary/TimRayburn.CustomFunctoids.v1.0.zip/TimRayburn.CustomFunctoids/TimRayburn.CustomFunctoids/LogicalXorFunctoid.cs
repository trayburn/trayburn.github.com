using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;


namespace TimRayburn.CustomFunctoids
{

    class LogicalXorFunctoid : BaseFunctoid
    {
        public LogicalXorFunctoid()
            : base()
        {
            // Assign a "unique" id to this functiod.
            this.ID = 24605;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_LOGICALXORFUNCTOID_NAME");
            SetTooltip("IDS_LOGICALXORFUNCTOID_TOOLTIP");
            SetDescription("IDS_LOGICALXORFUNCTOID_DESCRIPTION");
            SetBitmap("IDS_LOGICALXORFUNCTOID_BITMAP");

            this.SetMinParams(2);
            this.SetMaxParams(2);

            //set the function name that needs to be 
            //called when this Functoid is invoked. This means that
            //this Functoid assembly need to be present in GAC 
            //for its availability during Test..Map and Runtime.
            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.LogicalXorFunctoid",
                "LogicalXor");

            this.Category = FunctoidCategory.Logical;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }

        public string LogicalXor(string firstVal, string secondVal)
        {
            bool bFirst = System.Convert.ToBoolean(firstVal);
            bool bSecond = System.Convert.ToBoolean(secondVal);
            bool result = bFirst ^ bSecond;

            if (result)
                return "true";
            else
                return "false";
        }
    }
}
