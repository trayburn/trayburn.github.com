using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;
using System.Diagnostics;


namespace TimRayburn.CustomFunctoids
{
    class LogicalEndsWithFunctoid : BaseFunctoid
    {
        public LogicalEndsWithFunctoid()
            : base()
        {
            // Assign a "unique" id to this functiod.
            this.ID = 24608;

            // Setup the resource assembly to use.
            SetupResourceAssembly(
                "TimRayburn.CustomFunctoids.CustomFunctoidsResources",
                Assembly.GetExecutingAssembly());

            SetName("IDS_LOGICALENDSWITHFUNCTOID_NAME");
            SetTooltip("IDS_LOGICALENDSWITHFUNCTOID_TOOLTIP");
            SetDescription("IDS_LOGICALENDSWITHFUNCTOID_DESCRIPTION");
            SetBitmap("IDS_LOGICALENDSWITHFUNCTOID_BITMAP");

            this.SetMinParams(2);
            this.SetMaxParams(2);

            //set the function name that needs to be 
            //called when this Functoid is invoked. This means that
            //this Functoid assembly need to be present in GAC 
            //for its availability during Test..Map and Runtime.
            SetExternalFunctionName(this.GetType().Assembly.FullName,
                "TimRayburn.CustomFunctoids.LogicalEndsWithFunctoid",
                "LogicalEndsWith");

            this.Category = FunctoidCategory.Logical;
            this.OutputConnectionType = ConnectionType.AllExceptRecord;

            AddInputConnectionType(ConnectionType.AllExceptRecord);
        }

        public string LogicalEndsWith(string fullString, string subString)
        {
            if (fullString.EndsWith(subString))
                return "true";
            else
                return "false";
        }
    }
}
