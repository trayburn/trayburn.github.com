using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVPExample.Application
{
    public partial class Form1 : Form, MVPExample.View.IPostView
    {
        MVPExample.View.PostPresenter presenter;
        public Form1()
        {
            InitializeComponent();
            presenter = new MVPExample.View.PostPresenter(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            presenter.RetrievePost();
        }

        #region IPostView Members

        public int PostId
        {
            get 
            {
                return Convert.ToInt32(this.PostIdTextBox.Text);
            }
        }

        public string Title
        {
            set 
            {
                this.TitleLabel.Text = value;
            }
        }

        public string Body
        {
            set 
            {
                this.BodyTextBox.Text = value;
            }
        }

        #endregion
    }
}