using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace MVPExample.Model
{
    public class Post
    {
        private Post() { }  // Private Constructor

        internal string _Title;
        public string Title
        {
            get
            {
                return _Title;
            }
        }
        internal string _Body;
        public string Body
        {
            get
            {
                return _Body;
            }
        }
        public static Post GetPostById(int id)
        {
            XmlDocument posts = new XmlDocument();
            posts.Load("posts.xml");
            string strXpath = "/Posts/Post[@id={0}]/{1}";
            XmlNode titleNode = posts.SelectSingleNode(String.Format(strXpath,id,"Title"));
            XmlNode bodyNode = posts.SelectSingleNode(String.Format(strXpath, id, "Body"));

            Post retPost = new Post();
            retPost._Title = titleNode.InnerText;
            retPost._Body = bodyNode.InnerText;

            return retPost;
        }
    }
}
