using System;
using System.Collections.Generic;
using System.Text;
using MVPExample.Model;

namespace MVPExample.View
{
    public class PostPresenter
    {
        private readonly IPostView view;

        public PostPresenter(IPostView view)
        {
            this.view = view;
        }

        public void RetrievePost()
        {
            Post myPost = Post.GetPostById(view.PostId);
            view.Title = myPost.Title;
            view.Body = myPost.Body;
        }
    }
}
