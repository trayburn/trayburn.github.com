using System;
using System.Collections.Generic;
using System.Text;

namespace MVPExample.View
{
    public interface IPostView
    {
        int PostId { get; }
        string Title { set; }
        string Body { set; }
    }
}
