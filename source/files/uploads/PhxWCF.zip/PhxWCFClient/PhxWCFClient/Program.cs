﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhxWCFClient.Calc;

namespace PhxWCFClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var cal = new Calc.CalculatorClient();
            var result = cal.Add(new OperandPair()
            {
                FirstOperand = 2,
                SecondOperand = 2
            });
            Console.WriteLine(result.Result);
            Console.ReadLine();
        }
    }
}
