﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace PhxWCFService
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(Calculator));
            sh.Open();

            Console.WriteLine("Service is Running...");
            Console.ReadLine();

            sh.Close();
        }
    }

    [ServiceContract()]
    public interface ICalculator
    {
        [OperationContract()]
        CalculationResult Add(OperandPair pair);
    }

    [DataContract]
    public class OperandPair
    {
        [DataMember()]
        public int FirstOperand { get; set; }
        [DataMember]
        public int SecondOperand { get; set; }
    }

    public class CalculationResult
    {
        public int Result { get; set; }
        public OperandPair Operands { get; set; }
    }

    public class Calculator : ICalculator
    {
        public CalculationResult Add(OperandPair pair)
        {
            Console.WriteLine("Add");
            return new CalculationResult() 
            {
                Result=pair.FirstOperand + pair.SecondOperand,
                Operands=pair
            };
        }
    }






















    //[ServiceContract(Name="FooBar")]
    //public interface ICalculator
    //{
    //    [OperationContract]
    //    int Add(int firstOperand, int secondOperand);
    //    [OperationContract]
    //    int Subtract(int firstOperand, int secondOperand);
    //    [OperationContract]
    //    int Multiply(int firstOperand, int secondOperand);
    //    [OperationContract]
    //    int Divide(int firstOperand, int secondOperand);
    //}
    //public class Calculator : ICalculator
    //{
    //    public int Add(int firstOperand, int secondOperand)
    //    {
    //        return firstOperand + secondOperand;
    //    }
    //    public int Subtract(int firstOperand, int secondOperand)
    //    {
    //        return firstOperand - secondOperand;
    //    }
    //    public int Multiply(int firstOperand, int secondOperand)
    //    {
    //        return firstOperand * secondOperand;
    //    }
    //    public int Divide(int firstOperand, int secondOperand)
    //    {
    //        return firstOperand / secondOperand;
    //    }
    //}

    //ServiceHost sh = new ServiceHost(typeof(Calculator));
    //sh.Open();
    //Console.WriteLine("Service is Running ...");
    //Console.ReadLine();
    //sh.Close();

}
